<?php

use Illuminate\Support\Facades\Route;

// Define your Blog module routes here
Route::prefix('auth')->group(function() {
    // Your routes go here
}); 