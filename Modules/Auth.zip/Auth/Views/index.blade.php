<!DOCTYPE html>
<html>
<head>
    <title>Auth Module</title>
</head>
<body>
    <h1>Welcome to the Auth Module!</h1>
</body>
</html>
